#include "game_utilities.hpp"

TTF_Font* GameUtilities::_font = NULL;
int GameUtilities::_score = 0;
const char* GameUtilities::_highScoresFilePath = "data/highscores.txt";
int GameUtilities::_highScores[globals::MAX_HIGHSCORES] = {0};
/****
*THis class has some utility fucntion used in rendering the game 
*
*
***/
void GameUtilities::init()///initiazation utility function
{
    _font = TTF_OpenFont("Engine/spriteEditor/fonts/raidercrusader.ttf", 24);
    readHighScores();
}

void GameUtilities::close()///close utility fucntion
{
    TTF_CloseFont(_font);
}

void GameUtilities::renderText(SDL_Texture* texture, SDL_Rect rect, Vec2<int> offset)///displays text
{
    rect.x += offset.x;
    rect.y += offset.y;
    SDL_RenderCopy(SDL_Components::getRenderer(), texture, NULL, &rect);
    /***
    *int SDL_RenderCopy(SDL_Renderer * renderer,
                   SDL_Texture * texture,
                   const SDL_Rect * srcrect,
                   const SDL_Rect * dstrect);
    *Returns 0 on success or a negative error code on failure; call SDL_GetError() for more information.
    *The texture is blended with the destination based on its blend mode set with SDL_SetTextureBlendMode().

    * The texture color is affected based on its color modulation set by SDL_SetTextureColorMod().

    * The texture alpha is affected based on its alpha modulation set by SDL_SetTextureAlphaMod().
    ***/
}

int GameUtilities::getStrLen(const char *str)///obatin the lenght of message
{
    int lenght = 0;
    while(*str)
    {
        lenght += 1;
        str += 1;
    }
    return lenght;
}

int GameUtilities::getRandomNumber(int startRange, int endRange)///gives back a random number
{
    std::random_device rd;
    std::mt19937 eng(rd());
    std::uniform_int_distribution<> distr(startRange, endRange);

    return distr(eng);
}

bool GameUtilities::areColliding(SDL_Rect one, SDL_Rect two)///confirms if collson has actually occured
{
    if(!(one.x <= two.x))
    {
        SDL_Rect temp = one;
        one = two;
        two = temp;
    }

    if((one.x + one.w > two.x) && (two.y + two.h >= one.y && two.y < one.y + one.h))
        return true;
    return false;
}

void GameUtilities::readHighScores()///reads scores and puts them in a score sheet.
{
    ifstream highScoresFile (_highScoresFilePath, ios::in);

    if(!highScoresFile.is_open())//opens the file safely
    {
        cout << "Problem opening highscores file";
        return;
    }

    int iter = 0;
    while(iter < globals::MAX_HIGHSCORES && highScoresFile >> _highScores[iter++]);

    selectionSort(_highScores, globals::MAX_HIGHSCORES);
   
    highScoresFile.close();
}

void GameUtilities::writeHighScores()///writes scores user has
{
    ofstream highScoresFile (_highScoresFilePath, ios::out | ios::trunc);

    if(!highScoresFile.is_open())
    {
        cout << "Problem opening highscores file";
        return;
    }

    for(int i=0; i<globals::MAX_HIGHSCORES; i++)
        highScoresFile << _highScores[i] << "\n";
}

void GameUtilities::updateHighScores()///updfates the score sheet
{
    if(_score < _highScores[globals::MAX_HIGHSCORES - 1])
        return;

    for(int i=0; i<globals::MAX_HIGHSCORES; i++) ///insertion algorithm
    {
        if(_score > _highScores[i])
        {
            for(int j=globals::MAX_HIGHSCORES - 1; j>i; j--)
                _highScores[j] = _highScores[j - 1];

            _highScores[i] = _score;
            break;
        }
    }

    writeHighScores();
}

TTF_Font* const GameUtilities::getFont() {return _font;}///pust font
int GameUtilities::getScore() {return _score;}
void GameUtilities::setScore(int score) {_score = score;}

int* GameUtilities::getHighscores()//get highscores
{
    return _highScores;
}

template <typename T>
void GameUtilities::selectionSort(T* arr, int size)//sorting algorithm
{
    for(int i=0; i<size - 1; i++)
    {
        int maxIndex = i;
 /***
    *The selection sort algorithm sorts an array by repeatedly 
    * finding the minimum element (considering ascending order)
    * from unsorted part and putting it at the beginning.
    *  The algorithm maintains two subarrays in a given array.

    * 1) The subarray which is already sorted.
    *  2) Remaining subarray which is unsorted.

    * In every iteration of selection sort,
    *   the minimum element (considering ascending order) 
    * from the unsorted subarray is picked and moved to the sorted subarray
    *
    *
    *
    *
    ***/
        for(int j=i + 1; j<size; j++)
            if(arr[j] > arr[maxIndex])
                maxIndex = j;

        swap(arr[i], arr[maxIndex]);
    }
}

template <typename T>
void GameUtilities::swap(T& one, T& two)//swap function 
{
    T temp = one;
    one = two;
    two = temp;
    ///The function does not return anything, it swaps the values of the two variables.
}
