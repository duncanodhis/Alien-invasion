#include "button.hpp"
#include "game.hpp"
#include "main_menu_scene.hpp"
/***
*Implements button class.Button class decides what each button does
*
*
*
***/
Button::Button(Label* label, std::function<void()> func):///constructor to initalize each label condition
    _label(label), _func(func)
{
    _clickedOnce = false;
}

Button::~Button()
{
    delete _label;
}

void Button::update()///update the button conditions
{
    Vec2<int> mouseCoords = Vec2<int>(SDL_Components::getEvent()->motion.x, SDL_Components::getEvent()->motion.y);
    bool mouseOnTarget = (mouseCoords.x >= _label->getRect().x + _label->getOffset().x && mouseCoords.x <= _label->getRect().x + _label->getOffset().x + _label->getRect().w) &&
            (mouseCoords.y >= _label->getRect().y + _label->getOffset().y && mouseCoords.y <= _label->getRect().y + _label->getOffset().y + _label->getRect().h);
/***
*MouseCoords obatins the mouse events when clikced
*mouseTarget a variable that checks the button clicked
*
***/

    if(SDL_Components::getEvent()->type == SDL_MOUSEMOTION)///confirms that the mouse actualy moved
    {
        if(mouseOnTarget)///if mouse is clickcd on a target do the below conditions
            _label->setLabelColor(Colors::Red);///color should chnage to red
        else
            _label->setLabelColor(Colors::White);///color should remain white
    }
    else if(SDL_Components::getEvent()->type == SDL_MOUSEBUTTONDOWN && !_clickedOnce)//else if mouse is not clicked
    {
        if(mouseOnTarget)
        {
            _clickedOnce = true;
            _func();
        }
    }
    else if(SDL_Components::getEvent()->type == SDL_MOUSEBUTTONUP)///if mouse moves up button should be updated as seen in statement
    {
        _clickedOnce = false;
    }

    GameUtilities::renderText(_label->getTexture(), _label->getRect(), _label->getOffset());//text should be shopwn on click
}

Label* Button::getLabel() const {return _label;}
