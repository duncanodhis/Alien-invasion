#include "game.hpp"
//main function
using namespace std;
int main(int argc, char *argv[])
{
    Game alienAttack;
    int level;
    alienAttack.startGame();///starts the game
    cout<<"Select level \n";
    cout<<"1 2  3\n";
    cin>>level;
    if(level == 1){
    	alienAttack.startGame();///starts the game
    }
    else if (level==2)
    {
    alienAttack.startGame_1();///starts the game
    }
    else if (level==3)
    {
    	alienAttack.startGame_2();///starts the game
    }
    else{
    	alienAttack.startGame();///starts the game

    }
    


    return 0;
}
