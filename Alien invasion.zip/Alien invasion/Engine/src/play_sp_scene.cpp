#include "play_sp_scene.hpp"
//scene
PlaySPScene::PlaySPScene(): PlayScene()
{
    _ui = new UI();
}
//destructor
PlaySPScene::~PlaySPScene()
{

}
//update  game
void PlaySPScene::update()
{
    PlayScene::update();
}
