#include "barricades.hpp"
/***
*This is class barricade .its work is to form a barrier as a wall of protection 
*between the aliens and the space shooter
*
*
*
*
***/
Barricades::Barricades(Vec2<int> playerPos)
{
    /***
    *This is a class constructor used to initaslized 
    *the barricade size and put the sprite needed for this .
    *It positions the player in this barricades
     ***/
    for(int i=0; i<globals::BARRICADES_SIZE; i++)
        _barricads[i] = new Sprite("Engine/assets/sprites/currentSprites.png", {globals::GAME_WIDTH - (i+1) * 180, playerPos.y - 90, 100, 75}, {47, 487, 176, 128});
}

Barricades::~Barricades()
{
    for(int i=0; i<globals::BARRICADES_SIZE; i++)
    {
        if(!_barricads[i])
            continue;
        /***
        *puts the baricade in postion
        *
        *
        ***/

        delete _barricads[i];
        _barricads[i] = NULL;
    }
}
/***
This fucntion is used as a handler for the barricades put in place 
***/
void Barricades::handle(EnemyHorde* enemyHorde)
{
    for(int i=0; i<globals::BARRICADES_SIZE; i++)
    {
        if(!enemyHorde)///confirm that enemy group /position 
            return;
        if(!_barricads[i])
            continue;

        auto damageBarricade = [&]()///barricade is damaged
        {
            if(_barricads[i]->getAlpha() <= 40)
            {
                delete _barricads[i];///deletes baricade
                _barricads[i] = NULL;
                return;
            }

            _barricads[i]->setAlpha(_barricads[i]->getAlpha() - 10);
        };

        if(_barricads[i] && enemyHorde->isABulletColliding(_barricads[i]->getPosnsizeRect()))
            damageBarricade();

        for(uint j=0; j<Player::getBullets().size(); j++)
        {
            if(!_barricads[i])
                break;

            Bullet* currentBullet = Player::getBullets().at(j);
            if(GameUtilities::areColliding(currentBullet->getSprite()->getPosnsizeRect(), _barricads[i]->getPosnsizeRect()))
            {///confirms that there is a collision
                currentBullet->destroy();
                damageBarricade();
            }
        }
    }
}

void Barricades::draw() const///Baricade should put in display
{
    for(int i=0; i<globals::BARRICADES_SIZE; i++)
        if(_barricads[i])
            _barricads[i]->draw();//makes the baricade appear on the screen
}

Sprite ** const Barricades::getBarricades()///gtter function
{
    return _barricads;///returns barricade
}
