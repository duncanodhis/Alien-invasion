#include "game.hpp"
#include "main_menu_scene.hpp"

stack<Scene*> Game::_scenesStack;

Game::Game()//constructor
{
    SDL_Components::init();
    GameUtilities::init();

    SDL_Components::setVolume(10);///game volume editor

    _isGameOver = false;
    pushScene(new MainMenuScene());
}

Game::~Game()//destructor
{
    clearScenes();
    GameUtilities::close();
    SDL_Components::close();
}
//where game is tarted
void Game::startGame()
{
    while(!_isGameOver && SDL_Components::getEvent()->type != SDL_QUIT)
    {
        SDL_PollEvent(SDL_Components::getEvent());
        /***
        *int SDL_PollEvent(SDL_Event * event);
        *Returns 1 if there is a pending event or 0 if there are none available.
        *Remarks
        *If event is not NULL, the next event is removed from the queue and stored in the SDL_Event structure pointed to by event. The 1 returned refers to this event, immediately stored in the SDL Event structure -- not an event to follow.

        *If event is NULL, it simply returns 1 if there is an event in the queue, but will not remove it from the queue.

        *As this function implicitly calls SDL_PumpEvents(), you can only call this function in the thread that set the video mode.

        ***/
        SDL_RenderClear(SDL_Components::getRenderer());
        /***
        *int SDL_RenderClear(SDL_Renderer * renderer);
        *Returns 0 on success or a negative error code on failure; call SDL_GetError() for more information.
        *This function clears the entire rendering target, ignoring the viewport and the clip rectangle.
        ***/
        if(_scenesStack.size() != 0)
        {
            Scene* currScene = _scenesStack.top();
            if(currScene)
                currScene->update();
        }

        SDL_RenderPresent(SDL_Components::getRenderer());
        /***
        *void SDL_RenderPresent(SDL_Renderer * renderer);
        *Remarks
         *   SDL's rendering functions operate on a backbuffer; that is, 
         *   calling a rendering function such as SDL_RenderDrawLine() does not directly put a line on the screen,
         *   but rather updates the backbuffer. As such, 
         *   you compose your entire scene and present the composed backbuffer 
         *   to the screen as a complete picture.
         *
         *  Therefore, when using SDL's rendering API, one does all drawing intended 
         *  for the frame, and then calls this function once per frame to present the final drawing to the user.
         *
         *   The backbuffer should be considered invalidated after each present; 
         *  do not assume that previous contents will exist between frames. 
         *  You are strongly encouraged to call SDL_RenderClear() to initialize
         *   the backbuffer before starting each new frame's drawing, 
         *    even if you plan to overwrite every pixel.
        *
        ***/
    }

    SDL_Components::killApp();///ends game
}
void Game::startGame_1()
{
    while(!_isGameOver && SDL_Components::getEvent()->type != SDL_QUIT)
    {
        SDL_PollEvent(SDL_Components::getEvent());
        /***
        *int SDL_PollEvent(SDL_Event * event);
        *Returns 1 if there is a pending event or 0 if there are none available.
        *Remarks
        *If event is not NULL, the next event is removed from the queue and stored in the SDL_Event structure pointed to by event. The 1 returned refers to this event, immediately stored in the SDL Event structure -- not an event to follow.

        *If event is NULL, it simply returns 1 if there is an event in the queue, but will not remove it from the queue.

        *As this function implicitly calls SDL_PumpEvents(), you can only call this function in the thread that set the video mode.

        ***/
        SDL_RenderClear(SDL_Components::getRenderer());
        /***
        *int SDL_RenderClear(SDL_Renderer * renderer);
        *Returns 0 on success or a negative error code on failure; call SDL_GetError() for more information.
        *This function clears the entire rendering target, ignoring the viewport and the clip rectangle.
        ***/
        if(_scenesStack.size() != 0)
        {
            Scene* currScene = _scenesStack.top();
            if(currScene)
                currScene->update();
        }

        SDL_RenderPresent(SDL_Components::getRenderer());
        /***
        *void SDL_RenderPresent(SDL_Renderer * renderer);
        *Remarks
         *   SDL's rendering functions operate on a backbuffer; that is, 
         *   calling a rendering function such as SDL_RenderDrawLine() does not directly put a line on the screen,
         *   but rather updates the backbuffer. As such, 
         *   you compose your entire scene and present the composed backbuffer 
         *   to the screen as a complete picture.
         *
         *  Therefore, when using SDL's rendering API, one does all drawing intended 
         *  for the frame, and then calls this function once per frame to present the final drawing to the user.
         *
         *   The backbuffer should be considered invalidated after each present; 
         *  do not assume that previous contents will exist between frames. 
         *  You are strongly encouraged to call SDL_RenderClear() to initialize
         *   the backbuffer before starting each new frame's drawing, 
         *    even if you plan to overwrite every pixel.
        *
        ***/
    }

    SDL_Components::killApp();///ends game
}
void Game::startGame_2()
{
    while(!_isGameOver && SDL_Components::getEvent()->type != SDL_QUIT)
    {
        SDL_PollEvent(SDL_Components::getEvent());
        /***
        *int SDL_PollEvent(SDL_Event * event);
        *Returns 1 if there is a pending event or 0 if there are none available.
        *Remarks
        *If event is not NULL, the next event is removed from the queue and stored in the SDL_Event structure pointed to by event. The 1 returned refers to this event, immediately stored in the SDL Event structure -- not an event to follow.

        *If event is NULL, it simply returns 1 if there is an event in the queue, but will not remove it from the queue.

        *As this function implicitly calls SDL_PumpEvents(), you can only call this function in the thread that set the video mode.

        ***/
        SDL_RenderClear(SDL_Components::getRenderer());
        /***
        *int SDL_RenderClear(SDL_Renderer * renderer);
        *Returns 0 on success or a negative error code on failure; call SDL_GetError() for more information.
        *This function clears the entire rendering target, ignoring the viewport and the clip rectangle.
        ***/
        if(_scenesStack.size() != 0)
        {
            Scene* currScene = _scenesStack.top();
            if(currScene)
                currScene->update();
        }

        SDL_RenderPresent(SDL_Components::getRenderer());
        /***
        *void SDL_RenderPresent(SDL_Renderer * renderer);
        *Remarks
         *   SDL's rendering functions operate on a backbuffer; that is, 
         *   calling a rendering function such as SDL_RenderDrawLine() does not directly put a line on the screen,
         *   but rather updates the backbuffer. As such, 
         *   you compose your entire scene and present the composed backbuffer 
         *   to the screen as a complete picture.
         *
         *  Therefore, when using SDL's rendering API, one does all drawing intended 
         *  for the frame, and then calls this function once per frame to present the final drawing to the user.
         *
         *   The backbuffer should be considered invalidated after each present; 
         *  do not assume that previous contents will exist between frames. 
         *  You are strongly encouraged to call SDL_RenderClear() to initialize
         *   the backbuffer before starting each new frame's drawing, 
         *    even if you plan to overwrite every pixel.
        *
        ***/
    }

    SDL_Components::killApp();///ends game
}
///scene is pushed
void Game::pushScene(Scene* scene)
{
    _scenesStack.push(scene);
}
///scene is poped
void Game::popScene()
{
    if(_scenesStack.size() == 0)
        return;

    Scene* poppedScene = _scenesStack.top();
    _scenesStack.pop();
    delete poppedScene; // <-- Problemno
}
///clears scene

void Game::clearScenes()
{
    while(_scenesStack.size() > 0)
        popScene();
}
