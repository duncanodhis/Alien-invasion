#include "sprite.hpp"
///Sprite utility class
Sprite::Sprite(const char* imageLocation, SDL_Rect sizeRect)
{
    _position = Vec2<int>(sizeRect.x, sizeRect.y);
    _posnsizeRect = sizeRect;
    _texture = IMG_LoadTexture(SDL_Components::getRenderer(), imageLocation);
    _cropRect = {0, 0, 0, 0};
    _alpha = 100;

	if (_texture == NULL)
		cout << "Couldn't load image!" << endl;
}

Sprite::Sprite(const char* imageLocation, SDL_Rect sizeRect, SDL_Rect cropRect)
{
    _position = Vec2<int>(sizeRect.x, sizeRect.y);
    _posnsizeRect = sizeRect;
    _cropRect = cropRect;
    _texture = IMG_LoadTexture(SDL_Components::getRenderer(), imageLocation);
    _alpha = 100;

	if (_texture == NULL)
		cout << "Couldn't load image!" << endl;
}
///destructor overloaed
Sprite::Sprite(const Sprite& sprite)
{
    *this = sprite;
}
///destructor
Sprite::~Sprite()
{
	SDL_DestroyTexture(_texture);
}
//doperator fucntion for sprite
Sprite& Sprite::operator=(const Sprite& sprite)
{
    _texture = sprite.getTexture();
    _cropRect = sprite.getCropRect();
    _posnsizeRect = sprite.getPosnsizeRect();

    return *this;
}
///draws the sprites
void Sprite::draw() const
{
    if(_cropRect.w == 0)
        SDL_RenderCopy(SDL_Components::getRenderer(), _texture, NULL, &_posnsizeRect);
	else
        SDL_RenderCopy(SDL_Components::getRenderer(), _texture, &_cropRect, &_posnsizeRect);
}
///sets the sprites
void Sprite::setupSprite(SDL_Texture * texture, SDL_Rect cropRect, SDL_Rect posnsizeRect)
{
    setTexture(texture);//set textire
    setCropRect(cropRect);//draws the required box
    setPosnsizeRect(posnsizeRect);//size of the box is set
}
//setter fucntion for x,y position of the box
void Sprite::setPosition(Vec2<int> position)
{
    _position = position;
	_posnsizeRect.x = position.x;
	_posnsizeRect.y = position.y;
}

void Sprite::setAlpha(int alpha)
{
    _alpha = alpha;

    SDL_SetTextureAlphaMod(_texture, alpha);
    /***
    *int SDL_SetTextureAlphaMod(SDL_Texture * texture,
                           Uint8 alpha);
    *Returns 0 on success or a negative error code on failure; call SDL_GetError() for more information.
    *When this texture is rendered, during the copy operation the source alpha value is modulated by this alpha value according to the following formula:

    *srcA = srcA * (alpha / 255)

    *Alpha modulation is not always supported by the renderer; it will return -1 if alpha modulation is not supported.


    ***/
}
///set position
Vec2<int> Sprite::getPosition() const
{
    return _position;
}
//sets the texture
void Sprite::setTexture(SDL_Texture * texture)
{
    _texture = texture;
}
///set the require box
void Sprite::setCropRect(SDL_Rect cropRect)
{
    _cropRect = cropRect;
}
///sets postion of rectangle
void Sprite::setPosnsizeRect(SDL_Rect posnsizeRect)
{
    _posnsizeRect = posnsizeRect;
}
///get position
SDL_Texture * Sprite::getTexture() const
{
    return _texture;
}
///gets postion of rectangle
SDL_Rect Sprite::getCropRect() const
{
    return _cropRect;
}
///gets postion of rectangle
SDL_Rect Sprite::getPosnsizeRect() const
{
    return _posnsizeRect;
}
///gets Alpha
int Sprite::getAlpha() const
{
     return _alpha;
}
