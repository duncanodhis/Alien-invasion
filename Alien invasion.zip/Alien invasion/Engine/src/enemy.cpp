#include "enemy.hpp"
/***
*Implements class enemy for the aliens
*
***/
Enemy::Enemy(EnemyTypes enemyType, Vec2<int> position):///class constructor 
    _pos(position), _enemyType(enemyType)
{
    _spriteLocation = "Engine/assets/sprites/currentSprites.png";//obtains the aliens sprites

    switch(_enemyType)//switch statement for the type of enemy
    {
    case Radkata: _sizeRect = {_pos.x, _pos.y, 25, 25}; _cropRect01 = {45, 0, 64, 63}; _cropRect02 = {147, 0, 64, 64}; break;
    case Sashkata: _sizeRect = {_pos.x, _pos.y, 34, 25}; _cropRect01 = {32, 103, 88, 64}; _cropRect02 = {136, 103, 88, 64}; break;
    case Kirkata: _sizeRect = {_pos.x, _pos.y, 37, 25}; _cropRect01 = {19, 210, 96, 64}; _cropRect02 = {133 ,211, 96, 64}; break;
    case Genio: _sizeRect = {_pos.x, _pos.y, 73, 32}; _cropRect01 = {35, 307, 192, 84}; _cropRect02 = {35, 307, 192, 84}; break;
    }//draws the enemy 

    _sprite01 = new Sprite(_spriteLocation, _sizeRect, _cropRect01);//postion the sprite obtained
    _sprite02 = new Sprite(_spriteLocation, _sizeRect, _cropRect02);

    _isSpriteState01 = true;
    _spriteTransitionTimer = 0;
    _spriteTransitionTime = 1;
}

Enemy::~Enemy()///destructor
{
    delete _sprite01;
    delete _sprite02;
}

void Enemy::update(float deltaTime)///updates the enemy position as time passes by
{
    _spriteTransitionTimer += 1 * deltaTime;
    if(_spriteTransitionTimer >= _spriteTransitionTime)///checks to see that the transition timer is > transition time
    {
        _spriteTransitionTimer = 0;//sets the sprite transition time
        _isSpriteState01 = !_isSpriteState01;//sate of sprite is updated
    }

    _sprite01->setPosition(_pos);
    _sprite02->setPosition(_pos);

    if(_isSpriteState01)
        _sprite01->draw();
    else
        _sprite02->draw();
}

Vec2<int> Enemy::getPosition() const {return _pos;}///getter function for postion
SDL_Rect Enemy::getSize() const {return _sizeRect;}///enem size getter function
EnemyTypes Enemy::getType() const {return _enemyType;}///Enemy type getter fucntion

void Enemy::setPosition (Vec2<int> const& pos) {_pos = pos; _sizeRect.x = pos.x; _sizeRect.y = pos.y;}///a  seter for postion
