#include "enemy_horde.hpp"
#include "play_sp_scene.hpp"
#include "play_mp_scene.hpp"
/***
*putrs the enemy horde in postion and updates them
*
*
***/
EnemyHorde::EnemyHorde(Vec2<int> startPos):///constructor
    _pos(startPos)
{
    _maxUnitWidth = 38;
    _unitWDistance = _maxUnitWidth + 6;
    _unitHDistance = 32;
    _hordeSize = Vec2<int>(globals::ENEMY_HORDE_WIDTH * _unitWDistance, globals::ENEMY_HORDE_HEIGHT * _unitHDistance);
    _isHordeMovingRight = true;

    _moveTimer = 0;
    _moveTime = 2;

    _shootTimer = 0;
    _shootTime = 4;

    initHorde();

    _shootSound = Mix_LoadWAV("Media/sounds/enemyShoot.wav");
    _deadEnemySound = Mix_LoadWAV("Media/sounds/deadEnemy.wav");
}

EnemyHorde::~EnemyHorde()///destructor
{
    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
            if(_enemyHorde[i][j])
                delete _enemyHorde[i][j];///deletes the hordr at postion [i][j]

    for(uint i=0; i<_hordeBullets.size(); i++)
        delete _hordeBullets[i];///deletes the hordr at postion [i][j]

    Mix_FreeChunk(_shootSound);///The internal format for an audio chunk. This stores the sample data,
    /// the length in bytes of that data, and the volume to use when mixing the sample.
    Mix_FreeChunk(_deadEnemySound);//The internal format for an audio chunk. This stores the sample data,
    /// the length in bytes of that data, and the volume to use when mixing the sample.
    /***Mix_chunk():
    *
    
    *typedef struct Mix_Chunk {
    *    int allocated;
    *   Uint8 *abuf;
    *   Uint32 alen;
    *    Uint8 volume;     /Per-sample volume, 0-128 /
       } Mix_Chunk;

    
    

    *allocated
       * a boolean indicating whether to free abuf when the chunk is freed.
       * 0 if the memory was not allocated and thus not owned by this chunk.
        *1 if the memory was allocated and is thus owned by this chunk.
    *
    *
    *
    *
    ***/

}

void EnemyHorde::update(float deltaTime)///updates the postion of the horde
{
    _moveTimer += 1 * deltaTime;
    _shootTimer += 1 * deltaTime;

    if(_shootTimer > _shootTime)
    {
        hordeShoot();
        _shootTime = GameUtilities::getRandomNumber(1, 6);//time to shoot
        _shootTimer = 0;
    }
    if(_moveTimer > _moveTime)
    {
        _moveTimer = 0;
        moveHorde();///moves the aliens to the directions i.e left if itwas in right and vice versa 
    }

    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
    {
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(!_enemyHorde[i][j])
                continue;

            _enemyHorde[i][j]->update(deltaTime);
        }
    }

    for(uint i=0; i<_hordeBullets.size(); i++)
        static_cast<Bullet*>(_hordeBullets[i])->update(deltaTime);

    checkHordeCollision();
}


void EnemyHorde::initHorde()///initialzizes the horde postion number and value 
{
    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
    {
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(i <= globals::ENEMY_HORDE_HEIGHT / 2 - 1)
                _enemyHorde[i][j] = new Enemy(EnemyTypes::Radkata, _pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Radkata));

            else if(i > globals::ENEMY_HORDE_HEIGHT / 2 - 1 && i <= globals::ENEMY_HORDE_HEIGHT / 2 + 1)
                _enemyHorde[i][j] = new Enemy(EnemyTypes::Sashkata, _pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Sashkata));

            else
                _enemyHorde[i][j] = new Enemy(EnemyTypes::Kirkata, _pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Kirkata));
        }
    }
}

void EnemyHorde::checkHordeCollision()///checks for collision of bullets and horde 
{
    std::vector<Bullet*> playerBullets = Player::getBullets();

    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
    {
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(!_enemyHorde[i][j])
                continue;

            for(Uint32 k=0; k<playerBullets.size(); k++)
            {
                Bullet* playerBullet = playerBullets.at(k);

                if(GameUtilities::areColliding(_enemyHorde[i][j]->getSize(), playerBullet->getSprite()->getPosnsizeRect()))
                {///checks if aliens have collison with bullets
                    switch (_enemyHorde[i][j]->getType())
                    {
                        ///aliens score adjustment
                    case Radkata: GameUtilities::setScore(GameUtilities::getScore() + 30);
                    case Sashkata: GameUtilities::setScore(GameUtilities::getScore() + 20);
                    case Kirkata: GameUtilities::setScore(GameUtilities::getScore() + 10);
                    case Genio: break;
                    }

                    Mix_PlayChannel(-1, _deadEnemySound, 0);
                    /***
                    *int Mix_PlayChannel(int channel, Mix_Chunk *chunk, int loops)
                    *channel
                    *       Channel to play on, or -1 for the first free unreserved channel.
                    *
                    *loops Number of loops, -1 is infinite loops.
                     *      Passing one here plays the sample twice (1 loop).
                    *chunk  Sample to play.
                    *Play chunk on channel, or if channel is -1, pick the first free unreserved channel. The sample will play for loops+1 number of times, unless stopped by halt, or fade out, or setting a new expiration time of less time than it would have originally taken to play the loops, or closing the mixer.
                    *Note: this just calls Mix_PlayChannelTimed() with ticks set to -1.
                    *
                    *
                    *
                    *
                    *Returns: the channel the sample is played on. On any errors, -1 is returned.
                    ***/
                    erase_p(_enemyHorde[i][j]);//deletes alien position
                    playerBullet->destroy();
                    break;
                }
            }
        }
    }
}
///THis function checks to see that their is a collison of horde with the player
bool EnemyHorde::isCollidingWithPlayer(Vec2<int> playerPos) const
{
    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
    {
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(!_enemyHorde[i][j])
                continue;

            if(GameUtilities::areColliding(_enemyHorde[i][j]->getSize(), {playerPos.x, playerPos.y, globals::PLAYER_SPRITE_SIZE_X, globals::PLAYER_SPRITE_SIZE_Y}))
                return true;
        }
    }

    return false;
}
///checks to see if there is actually elimination of one member of the horde
///returns true or false

bool EnemyHorde::isABulletColliding(SDL_Rect posnrect)
{
    Bullet* currentBullet = NULL;

    for(Uint32 i=0; i<_hordeBullets.size(); i++)
    {
        currentBullet = _hordeBullets[i];
        if(GameUtilities::areColliding(currentBullet->getSprite()->getPosnsizeRect(), {posnrect.x, posnrect.y, posnrect.w, posnrect.h}))
        {
            _hordeBullets.erase(std::remove(_hordeBullets.begin(), _hordeBullets.end(), currentBullet), _hordeBullets.end());
            erase_p(currentBullet);
            return true;
        }
    }

    return false;
}

void EnemyHorde::moveHorde()//moves the horde left to right and back forth
{
    int moveStep = (globals::GAME_WIDTH - _hordeSize.x) / 10;///setps to be moved

    if(_isHordeMovingRight)
    {///checks if we are moving to the right
        if(_pos.x + _hordeSize.x + moveStep > globals::GAME_WIDTH)//horizontal movement is taken into account
        {
            _isHordeMovingRight = ! _isHordeMovingRight;
            _pos.y += _unitHDistance;
            return;
        }

        _pos = _pos + Vec2<int>(moveStep, 0);
    }
    else
    {
        if(_pos.x - moveStep < 0)
        {
            _isHordeMovingRight = ! _isHordeMovingRight;
            _pos.y += _unitHDistance;
            return;
        }

        _pos = _pos - Vec2<int>(moveStep, 0);
    }

    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
    {
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(!_enemyHorde[i][j])
                continue;

            if(i <= globals::ENEMY_HORDE_HEIGHT / 2 - 1)
                _enemyHorde[i][j]->setPosition(_pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Radkata));

            else if(i > globals::ENEMY_HORDE_HEIGHT / 2 - 1 && i <= globals::ENEMY_HORDE_HEIGHT / 2 + 1)
                _enemyHorde[i][j]->setPosition(_pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Sashkata));

            else
                _enemyHorde[i][j]->setPosition(_pos + Vec2<int>(j * _unitWDistance, i * _unitHDistance) + getEnemyOffsetInHorde(Kirkata));
        }
    }
}
///ensures bullets move from player to the horde for shooting
void EnemyHorde::hordeShoot()
{
    for(int i=globals::ENEMY_HORDE_HEIGHT - 1; i>=0; i--)
    {
        vector<int> avaivableShooters;

        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
        {
            if(!_enemyHorde[i][j] || (i < globals::ENEMY_HORDE_HEIGHT - 1 && _enemyHorde[i + 1][j]))
                continue;

            avaivableShooters.push_back(j);
        }

        if(avaivableShooters.size() == 0)
            continue;

        Mix_PlayChannel(-1, _shootSound, 0);
        int shooterIndex = avaivableShooters.at(GameUtilities::getRandomNumber(0, avaivableShooters.size() - 1));
        _hordeBullets.push_back(new Bullet(new Sprite("Engine/assets/sprites/enemyBullet.png", {0, 0, 4, 25}), _enemyHorde[i][shooterIndex]->getPosition() + Vec2<int>(_enemyHorde[i][shooterIndex]->getSize().w/2, _enemyHorde[i][shooterIndex]->getSize().h), false));
    }
}

Vec2<int> EnemyHorde::getEnemyOffsetInHorde(EnemyTypes type)///obatins the enemy offset,emeber destroyed
{
    Vec2<int> offset = Vec2<int>(0,0);

    switch (type)
    {
    case Radkata: offset.x = 6; break;
    case Sashkata: offset.x = 1; break;
    case Kirkata: offset.x = 0; break;
    case Genio: break;
    }

    return offset;
}

bool EnemyHorde::isEmpty() const///cheks for total horde destruction
{
    for(int i=0; i<globals::ENEMY_HORDE_HEIGHT; i++)
        for(int j=0; j<globals::ENEMY_HORDE_WIDTH; j++)
            if(_enemyHorde[i][j])
                return false;

    return true;
}
//getters
Vec2<int> EnemyHorde::getHordeSize() const {return _hordeSize;}
Vec2<int> EnemyHorde::getHordePos() const {return _pos;}
