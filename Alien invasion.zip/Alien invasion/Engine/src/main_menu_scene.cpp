#include "main_menu_scene.hpp"
///Main menu is displayed using this class
MainMenuScene::MainMenuScene() : Scene()
{
    _introLabel = new Label("Welcome to Alien Attack! ", Vec2<int>(globals::SCREEN_CENTER.x, 0), Colors::White, 7);
    _introLabel->setOffset(Vec2<int>(0, -_introLabel->getRect().y * 3));

    _creditsLabel = new Label("Developed by Yunxiang Li", Vec2<int>(globals::GAME_WIDTH, globals::GAME_HEIGHT), Colors::White, 2);
    _creditsLabel->setOffset(Vec2<int>(-_creditsLabel->getRect().w / 1.8f, -_creditsLabel->getRect().h * 1.5f));

    _playSPButton = new Button(new Label("Single-player", Vec2<int>(globals::SCREEN_CENTER), Colors::White, 5), [&]() { Game::pushScene(new PlaySPScene()); });

    _playSPButton->getLabel()->setOffset(Vec2<int>(0, (_playSPButton->getLabel()->getRect().h * -2)));


   _playMPButton_1 = new Button(new Label("Multiplayer", Vec2<int>(globals::SCREEN_CENTER), Colors::White, 5), []() { Game::pushScene(new PlayMPScene()); });
   
    _playMPButton = new Button(new Label("Multiplayer", Vec2<int>(globals::SCREEN_CENTER), Colors::White, 5), []() { Game::pushScene(new PlayMPScene()); });
    _creditialsButton = new Button(new Label("About", Vec2<int>(globals::SCREEN_CENTER), Colors::White, 5), []() { cout << "You clicked Credits" << endl; GameUtilities::printScore(); });
    _creditialsButton->getLabel()->setOffset(Vec2<int>(0, (_creditialsButton->getLabel()->getRect().h * 2)));
     
    _highScoresButton = new Button(new Label("Highscores", Vec2<int>(globals::SCREEN_CENTER), Colors::White, 5), [&](){ Game::pushScene(new HighscoreScene()); });
    _highScoresButton->getLabel()->setOffset(Vec2<int>(0, (_creditialsButton->getLabel()->getRect().h * 4)));

    _introMusic = Mix_LoadMUS("Media/sounds/introMusic.wav");
    Mix_PlayMusic(_introMusic, -1);
}
//destructor
MainMenuScene::~MainMenuScene()
{
    delete _introLabel;
    delete _creditsLabel;
    delete _playSPButton;
    delete _playMPButton;
    delete _creditialsButton;
    delete _highScoresButton;
    delete  _playMPButton_1;
    delete  _playSPButton_2;

    Mix_FreeMusic(_introMusic);
}
//updates the game
void MainMenuScene::update()
{
    GameUtilities::renderText(_introLabel->getTexture(), _introLabel->getRect(), _introLabel->getOffset());
    GameUtilities::renderText(_creditsLabel->getTexture(), _creditsLabel->getRect(), _creditsLabel->getOffset());

    _playSPButton->update();
    _playMPButton->update();
    _creditialsButton->update();
    _highScoresButton->update();
}
