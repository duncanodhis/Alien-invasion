#include "ui.hpp"
//implemenets the user interface
UI::UI(bool multiplayer)
{
    initScoreBoard();///initialzes the board
    initHealthBars(multiplayer);///initialzes health score
}
//destructor
UI::~UI()
{
    delete _scoreTextLabel;
    delete _scoreNumLabel;
    delete _hpBarP1;
    delete _hpBarP2;
}
//ensures as you get killed health score reduces
void UI::reduceHealthBarOne()
{
    _hpBarP1->reduce();
}
///reduces 2nd bar
void UI::reduceHealthBarTwo()
{
    _hpBarP2->reduce();
}
///gives player only one life
int UI::getPlayerOneLives()
{
    return _hpBarP1->getLives();
}
///gives player 2 lives
int UI::getPlayerTwoLives()
{
    return _hpBarP2->getLives();
}
//draws healthbar 
void UI::drawHealthBars()
{
    _hpBarP1->update();
    _hpBarP2->update();
}

void UI::initHealthBars(bool multiplayer)
{
    _hpBarP1 = new HealthBar(globals::PLAYER_HEALTH);

    if(multiplayer)
        _hpBarP2 = new HealthBar(globals::PLAYER_HEALTH, true);
    else
        _hpBarP2 = new HealthBar(-1, true);
}

void UI::updateScoreBoard(int newScore)
{
    _scoreNumLabel->setText(to_string(newScore).c_str());
}

void UI::drawScoreBoard()
{
    GameUtilities::renderText(_scoreTextLabel->getTexture(), _scoreTextLabel->getRect(), _scoreTextLabel->getOffset());
    GameUtilities::renderText(_scoreNumLabel->getTexture(), _scoreNumLabel->getRect(), _scoreNumLabel->getOffset());
}

void UI::initScoreBoard()
{
    _scoreTextLabel = new Label("Score: ", Vec2<int>(0, 0), Colors::White, 3);
    _scoreTextLabel->setOffset(Vec2<int>(_scoreTextLabel->getRect().w / 1.9f, _scoreTextLabel->getRect().h * 0.8f));
    _scoreNumLabel = new Label("0", Vec2<int>(_scoreTextLabel->getPos().x + _scoreTextLabel->getRect().w * 1.5f, _scoreTextLabel->getOffset().y), Colors::Green, 3);
}
