
import os
import platform

# (1)==================== COMMON CONFIGURATION OPTIONS ======================= #
COMPILER="g++ -std=c++17"   # The compiler we want to use 
                                #(You may try g++ if you have trouble)
SOURCE="Engine/src/*.cpp"    # Where the source code lives

EXECUTABLE="platformer"        # Name of the final executable
# ======================= COMMON CONFIGURATION OPTIONS ======================= #

# (2)=================== Platform specific configuration ===================== #
# For each platform we need to set the following items
ARGUMENTS=""            # Arguments needed for our program (Add others as you see fit)
INCLUDE_DIR=""          # Which directories do we want to include.
LIBRARIES=""            # What libraries do we want to include

if platform.system()=="Linux":
    ARGUMENTS="-D LINUX" # -D is a #define sent to preprocessor
    INCLUDE_DIR="-I Engine/include/ -I ./../common/thirdparty/glm/"
    LIBRARIES="-lSDL2 -ldl -lSDL2main -lSDL2 -lSDL2_image -lSDL2_mixer -lSDL2_ttf -lpthread"
elif platform.system()=="Darwin":
    LINK_DIR = ''
    ARGUMENTS="-D MAC" # -D is a #define sent to the preprocessor.
    INCLUDE_DIR="-I ./include/ -I/Library/Frameworks/SDL2.framework/Headers -I/Library/Frameworks/SDL2_mixer.framework/Headers -I/Library/Frameworks/SDL2_ttf.framework/Headers -I/Library/Frameworks/SDL2_image.framework/Headers"
    LIBRARIES="-F/Library/Frameworks -framework SDL2 -F/Library/Frameworks -framework SDL2_mixer -F/Library/Frameworks -framework SDL2_ttf -F/Library/Frameworks -framework SDL2_image"
elif platform.system()=="Windows":
    COMPILER="g++ -std=c++17" # Note we use g++ here as it is more likely what you have
    ARGUMENTS="-g -D MINGW -std=c++17 -static-libgcc -static-libstdc++" 
    INCLUDE_DIR="-I Engine/include/ -I./../common/thirdparty/old/glm/"
    LINK_DIR = "-L./lib/"
    EXECUTABLE="bin/platformer.exe"
    LIBRARIES="-lmingw32 -lSDL2main -lSDL2 -lSDL2_ttf -lSDL2_image -lSDL2_mixer -mwindows"
# (2)=================== Platform specific configuration ===================== #

# (3)====================== Building the Executable ========================== #
# Build a string of our compile commands that we run in the terminal
compileString=COMPILER+" "+ARGUMENTS+" -o "+EXECUTABLE+" " + INCLUDE_DIR+" "+SOURCE+" "+LIBRARIES
# Print out the compile string
# This is the command you can type
print("============v (Command running on terminal) v===========================")
print("Compilng on: "+platform.system())
print(compileString)
print("========================================================================")
# Run our command
os.system(compileString)
# ==================